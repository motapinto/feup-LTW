T02G27

Martim Silva up201705205 - 50 %
Luis Ramos up201706253   - 50 %

all acounts have password ABCabc123
p.e: email: ms@gmail.com pass: ABCabc123

datepicker - calendar
galleria - photo galery viewing a property item (all the others were done without it)
icons - fontaswome
input in filter (double range input and checkbox) - materialize