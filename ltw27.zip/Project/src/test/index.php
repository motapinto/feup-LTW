<p>
    <?=htmlentities('<script>alert("ok")</script>', ENT_QUOTES, 'UTF-8')?>
</p>
