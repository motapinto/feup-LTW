  
<?php
  header('Location: src/listings/listings_all.php');
?>